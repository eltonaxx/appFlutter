class Pessoa {
  // Variáveis
  String nome;
  double peso;
  double altura;

}