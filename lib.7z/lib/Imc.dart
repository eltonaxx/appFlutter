import 'Pessoa.dart';

Pessoa persona=Pessoa() ;
class Imc {
  double calcularImc(persona) =>
      persona.peso / (persona.altura * persona.altura);
}

